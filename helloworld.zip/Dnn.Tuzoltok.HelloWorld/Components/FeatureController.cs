/*
' Copyright (c) 2024 Tuzoltok
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

//using System.Xml;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Services.Search;
using System.Collections.Generic;

namespace Helloworld.Dnn.Dnn.Tuzoltok.HelloWorld.Components
{
    /// -----------------------------------------------------------------------------
    /// <summary>
    /// The Controller class for Dnn.Tuzoltok.HelloWorld
    /// 
    /// The FeatureController class is defined as the BusinessController in the manifest file (.dnn)
    /// DotNetNuke will poll this class to find out which Interfaces the class implements. 
    /// 
    /// The IPortable interface is used to import/export content from a DNN module
    /// 
    /// The ISearchable interface is used by DNN to index the content of a module
    /// 
    /// The IUpgradeable interface allows module developers to execute code during the upgrade 
    /// process for a module.
    /// 
    /// Below you will find stubbed out implementations of each, uncomment and populate with your own data
    /// </summary>
    /// -----------------------------------------------------------------------------

    //uncomment the interfaces to add the support.
    public class FeatureController //: IPortable, ISearchable, IUpgradeable
    {


        #region Optional Interfaces

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// ExportModule implements the IPortable ExportModule Interface
        /// </summary>
        /// <param name="ModuleID">The Id of the module to be exported</param>
        /// -----------------------------------------------------------------------------
        //public string ExportModule(int ModuleID)
        //{
        //string strXML = "";

        //List<Dnn.Tuzoltok.HelloWorldInfo> colDnn.Tuzoltok.HelloWorlds = GetDnn.Tuzoltok.HelloWorlds(ModuleID);
        //if (colDnn.Tuzoltok.HelloWorlds.Count != 0)
        //{
        //    strXML += "<Dnn.Tuzoltok.HelloWorlds>";

        //    foreach (Dnn.Tuzoltok.HelloWorldInfo objDnn.Tuzoltok.HelloWorld in colDnn.Tuzoltok.HelloWorlds)
        //    {
        //        strXML += "<Dnn.Tuzoltok.HelloWorld>";
        //        strXML += "<content>" + DotNetNuke.Common.Utilities.XmlUtils.XMLEncode(objDnn.Tuzoltok.HelloWorld.Content) + "</content>";
        //        strXML += "</Dnn.Tuzoltok.HelloWorld>";
        //    }
        //    strXML += "</Dnn.Tuzoltok.HelloWorlds>";
        //}

        //return strXML;

        //	throw new System.NotImplementedException("The method or operation is not implemented.");
        //}

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// ImportModule implements the IPortable ImportModule Interface
        /// </summary>
        /// <param name="ModuleID">The Id of the module to be imported</param>
        /// <param name="Content">The content to be imported</param>
        /// <param name="Version">The version of the module to be imported</param>
        /// <param name="UserId">The Id of the user performing the import</param>
        /// -----------------------------------------------------------------------------
        //public void ImportModule(int ModuleID, string Content, string Version, int UserID)
        //{
        //XmlNode xmlDnn.Tuzoltok.HelloWorlds = DotNetNuke.Common.Globals.GetContent(Content, "Dnn.Tuzoltok.HelloWorlds");
        //foreach (XmlNode xmlDnn.Tuzoltok.HelloWorld in xmlDnn.Tuzoltok.HelloWorlds.SelectNodes("Dnn.Tuzoltok.HelloWorld"))
        //{
        //    Dnn.Tuzoltok.HelloWorldInfo objDnn.Tuzoltok.HelloWorld = new Dnn.Tuzoltok.HelloWorldInfo();
        //    objDnn.Tuzoltok.HelloWorld.ModuleId = ModuleID;
        //    objDnn.Tuzoltok.HelloWorld.Content = xmlDnn.Tuzoltok.HelloWorld.SelectSingleNode("content").InnerText;
        //    objDnn.Tuzoltok.HelloWorld.CreatedByUser = UserID;
        //    AddDnn.Tuzoltok.HelloWorld(objDnn.Tuzoltok.HelloWorld);
        //}

        //	throw new System.NotImplementedException("The method or operation is not implemented.");
        //}

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// GetSearchItems implements the ISearchable Interface
        /// </summary>
        /// <param name="ModInfo">The ModuleInfo for the module to be Indexed</param>
        /// -----------------------------------------------------------------------------
        //public DotNetNuke.Services.Search.SearchItemInfoCollection GetSearchItems(DotNetNuke.Entities.Modules.ModuleInfo ModInfo)
        //{
        //SearchItemInfoCollection SearchItemCollection = new SearchItemInfoCollection();

        //List<Dnn.Tuzoltok.HelloWorldInfo> colDnn.Tuzoltok.HelloWorlds = GetDnn.Tuzoltok.HelloWorlds(ModInfo.ModuleID);

        //foreach (Dnn.Tuzoltok.HelloWorldInfo objDnn.Tuzoltok.HelloWorld in colDnn.Tuzoltok.HelloWorlds)
        //{
        //    SearchItemInfo SearchItem = new SearchItemInfo(ModInfo.ModuleTitle, objDnn.Tuzoltok.HelloWorld.Content, objDnn.Tuzoltok.HelloWorld.CreatedByUser, objDnn.Tuzoltok.HelloWorld.CreatedDate, ModInfo.ModuleID, objDnn.Tuzoltok.HelloWorld.ItemId.ToString(), objDnn.Tuzoltok.HelloWorld.Content, "ItemId=" + objDnn.Tuzoltok.HelloWorld.ItemId.ToString());
        //    SearchItemCollection.Add(SearchItem);
        //}

        //return SearchItemCollection;

        //	throw new System.NotImplementedException("The method or operation is not implemented.");
        //}

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// UpgradeModule implements the IUpgradeable Interface
        /// </summary>
        /// <param name="Version">The current version of the module</param>
        /// -----------------------------------------------------------------------------
        //public string UpgradeModule(string Version)
        //{
        //	throw new System.NotImplementedException("The method or operation is not implemented.");
        //}

        #endregion

    }

}
